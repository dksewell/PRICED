#' @import magrittr
#' @import dplyr
#' @import adaptMCMC
#' @import methods
#' @import coda
#' @import tibble
#' @importFrom numDeriv hessian
#' @exportClass PRICED

